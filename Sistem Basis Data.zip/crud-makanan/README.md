# Aplikasi CRUD Makanan

Aplikasi ini dibuat menggunakan PHP dan HTML untuk mengelola data makanan yang disimpan di database MySQL.

## Fitur:
- Menambah data makanan
- Melihat daftar makanan
- Mengedit data makanan
- Menghapus data makanan

## Cara Menjalankan
1. Import file `makanan.sql` ke database MySQL.
2. Pastikan file `koneksi.php` sudah sesuai dengan konfigurasi lokal Anda.
3. Jalankan `index.php` melalui server lokal (XAMPP, WAMP, atau lainnya).

## Struktur Folder
- index.php
- tambah.php
- edit.php
- update.php
- hapus.php
- koneksi.php
- makanan.sql
- README.md
CREATE DATABASE IF NOT EXISTS db_makanan;

USE db_makanan;

CREATE TABLE makanan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    jenis VARCHAR(50),
    harga INT
);

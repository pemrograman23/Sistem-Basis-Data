<?php
include 'koneksi.php';
$nama = $_POST['nama'];
$jenis = $_POST['jenis'];
$harga = $_POST['harga'];

$conn->query("INSERT INTO makanan (nama, jenis, harga) VALUES ('$nama', '$jenis', '$harga')");
header("Location: index.php");
?>
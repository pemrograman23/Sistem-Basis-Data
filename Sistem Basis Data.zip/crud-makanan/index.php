<?php include 'koneksi.php'; ?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Daftar Makanan - Halloween Theme</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #222831;
            color: #DFD0B8;
            margin: 0;
            padding: 40px;
        }

        .container {
            max-width: 900px;
            background-color: #393E46;
            padding: 30px;
            border-radius: 12px;
            margin: auto;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
            position: relative;
        }

        h2 {
            text-align: center;
            color: #DFD0B8;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        form {
            margin-bottom: 30px;
        }

        label {
            display: block;
            margin-top: 15px;
            color: #DFD0B8;
            font-weight: bold;
        }

        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 10px;
            margin-top: 6px;
            border: 1px solid #948979;
            background-color: #222831;
            color: #DFD0B8;
            border-radius: 6px;
        }

        button {
            margin-top: 20px;
            padding: 12px 25px;
            background-color: #948979;
            color: #222831;
            border: none;
            border-radius: 6px;
            font-weight: bold;
            cursor: pointer;
            width: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        button:hover {
            background-color: #DFD0B8;
            color: #222831;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #222831;
            color: #DFD0B8;
            border-radius: 8px;
            overflow: hidden;
        }

        th,
        td {
            padding: 12px;
            border: 1px solid #948979;
            text-align: left;
        }

        th {
            background-color: #393E46;
            color: #DFD0B8;
        }

        a {
            text-decoration: none;
            color: #DFD0B8;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }

        a:hover {
            text-decoration: underline;
        }

        .actions a {
            margin-right: 10px;
        }

        .svg-icon {
            width: 20px;
            height: 20px;
            fill: currentColor;
        }

        .pumpkin-header {
            width: 32px;
            height: 32px;
            fill: #DFD0B8;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>
            Daftar Makanan
        </h2>

        <form action="tambah.php" method="POST">
            <label for="nama">Nama Makanan</label>
            <input type="text" name="nama" required>

            <label for="jenis">Jenis</label>
            <input type="text" name="jenis" required>

            <label for="harga">Harga</label>
            <input type="number" name="harga" required>

            <button type="submit">
                <svg class="svg-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                    <path d="M19 11h-6V5h-2v6H5v2h6v6h2v-6h6z" />
                </svg>
                Tambah Makanan
            </button>
        </form>

        <table>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Jenis</th>
                <th>Harga</th>
                <th>Aksi</th>
            </tr>
            <?php
            $result = $conn->query("SELECT * FROM makanan");
            $no = 1;
            while ($row = $result->fetch_assoc()):
                ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= htmlspecialchars($row['nama']) ?></td>
                    <td><?= htmlspecialchars($row['jenis']) ?></td>
                    <td>Rp <?= number_format($row['harga'], 0, ',', '.') ?></td>
                    <td class="actions">
                        <a href="edit.php?id=<?= $row['id'] ?>">
                            <svg class="svg-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                <path
                                    d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM21.41 6.34c.38-.38.38-1.02 0-1.41L19.07 2.59c-.39-.39-1.03-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z" />
                            </svg>
                            Edit
                        </a>
                        <a href="hapus.php?id=<?= $row['id'] ?>"
                            onclick="return confirm('Yakin ingin menghapus makanan ini?')">
                            <svg class="svg-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                <path d="M16 9v10H8V9h8m-1.5-6h-5l-1 1H5v2h14V4h-4.5l-1-1z" />
                            </svg>
                            Hapus
                        </a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    </div>
</body>

</html>
<?php
include 'koneksi.php';
$id = $_POST['id'];
$nama = $_POST['nama'];
$jenis = $_POST['jenis'];
$harga = $_POST['harga'];

$conn->query("UPDATE makanan SET nama='$nama', jenis='$jenis', harga='$harga' WHERE id=$id");
header("Location: index.php");
?>
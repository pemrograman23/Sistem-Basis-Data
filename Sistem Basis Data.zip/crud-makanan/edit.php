<?php
include 'koneksi.php';
$id = $_GET['id'];
$result = $conn->query("SELECT * FROM makanan WHERE id = $id");
$data = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Edit Makanan</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #222831;
            color: #DFD0B8;
            margin: 0;
            padding: 40px;
        }

        .container {
            max-width: 600px;
            background-color: #393E46;
            padding: 30px;
            border-radius: 12px;
            margin: auto;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
            position: relative;
        }

        h2 {
            text-align: center;
            color: #DFD0B8;
            margin-bottom: 25px;
        }

        form {
            margin-top: 20px;
        }

        label {
            display: block;
            margin-top: 15px;
            color: #DFD0B8;
            font-weight: bold;
        }

        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 10px;
            margin-top: 6px;
            border: 1px solid #948979;
            background-color: #222831;
            color: #DFD0B8;
            border-radius: 6px;
        }

        button {
            margin-top: 20px;
            padding: 12px 25px;
            background-color: #948979;
            color: #222831;
            border: none;
            border-radius: 6px;
            font-weight: bold;
            cursor: pointer;
            width: 100%;
        }

        button:hover {
            background-color: #DFD0B8;
            color: #222831;
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #DFD0B8;
            text-decoration: none;
        }

        .back-link:hover {
            text-decoration: underline;
        }

        .svg-icon {
            position: absolute;
            top: -40px;
            left: -40px;
            width: 100px;
        }
    </style>
</head>

<body>
    <div class="container">

        <h2>Edit Data Makanan</h2>

        <form action="update.php" method="POST">
            <input type="hidden" name="id" value="<?= $data['id'] ?>">

            <label for="nama">Nama Makanan</label>
            <input type="text" name="nama" value="<?= htmlspecialchars($data['nama']) ?>" required>

            <label for="jenis">Jenis</label>
            <input type="text" name="jenis" value="<?= htmlspecialchars($data['jenis']) ?>" required>

            <label for="harga">Harga</label>
            <input type="number" name="harga" value="<?= htmlspecialchars($data['harga']) ?>" required>

            <button type="submit">Simpan Perubahan</button>
        </form>

        <a class="back-link" href="index.php">← Kembali ke Daftar</a>
    </div>
</body>

</html>